# Critical and Important Issues

## Critical

None found. The evidence supports the claims made: A renders, it survives a source edit without a rebuild, B renders after the rebuild, and B survives a restart.

## Important

### I1. `prepare.sh` does not make CocoaPods use the committed lock

- **Severity:** Important
- **File:** `spikes/ios-updates/prepare.sh:14-16`
- **Problem:** The lock is copied only when it exists (`if [[ -f Podfile.lock ]]`), and then plain `pod install` runs. Plain `pod install` can change the lock without failing. Two cases cause this:
  - The regenerated template `Podfile` differs. `npx … init --version 0.86.0` pulls the template from the registry, and the result is not checksummed or committed. `Podfile.lock` records `PODFILE CHECKSUM: af9be594…`.
  - A podspec resolves differently.

  In either case CocoaPods re-resolves and rewrites `.work/app/ios/Podfile.lock`. The script still exits 0, so the run looks like a "pinned" install. The comment "Freeze native dependencies" and the doc row "Pinned dependency installation | PASS" claim more than the script enforces. If the lock is missing, for example after a bad checkout, the script resolves pods fresh and says nothing.
- **Fix:** Require the lock and use deployment mode. It fails when the Podfile and lock disagree. Then assert the lock was not rewritten.

```bash
[[ -f Podfile.lock ]] || { echo 'Committed Podfile.lock is required.' >&2; exit 1; }
cp Podfile.lock .work/app/ios/
(cd .work/app/ios && pod install --deployment)
cmp -s Podfile.lock .work/app/ios/Podfile.lock || {
  echo 'pod install changed Podfile.lock; native dependencies drifted.' >&2; exit 1;
}
```

Also check the CocoaPods version, which the README requires but neither script verifies:

```bash
[[ "$(pod --version)" == 1.16.2 ]] || { echo 'Use CocoaPods 1.16.2.' >&2; exit 1; }
```

### I2. Committed evidence contains absolute home-directory paths

- **Severity:** Important (privacy and portability)
- **Files:** `spikes/ios-updates/evidence/bundle-A.sha256:1`, `spikes/ios-updates/evidence/bundle-B.sha256:1`, `spikes/ios-updates/evidence/build-{A,B}.log.gz` (many `cd /Users/<user>/git/agentui/...` lines), and `spikes/ios-updates/rebuild.sh:36`
- **Problem:** `shasum` is given an absolute path, so each committed `.sha256` file records the operator's local username and checkout location. The xcodebuild logs repeat that path thousands of times. This leaks local account details into a pushed repository. It also means `shasum -c` cannot check the files from any other checkout.
- **Fix:** Hash from inside the product directory so the recorded path is relative. Then regenerate the two `.sha256` files. For the logs, either accept the leak knowingly or redact before compressing, for example `sed "s#$HOME#~#g"`.

```bash
(cd "$product" && shasum -a 256 main.jsbundle) > ".work/evidence/bundle-$revision.sha256"
```

Committed files can be corrected by hand without a rebuild, because the hashes themselves are valid:

```
b95de99c60d9f927e42172d03d6a7200e239617fe941c36b830814684bd99808  main.jsbundle
```
