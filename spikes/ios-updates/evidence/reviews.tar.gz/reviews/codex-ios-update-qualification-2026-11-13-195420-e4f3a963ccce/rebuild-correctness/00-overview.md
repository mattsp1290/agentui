# Review Overview

- **Branch:** `codex/ios-update-qualification`
- **Head:** `e4f3a963ccce848e2e8c4e3d7d5337e53acb16c1` (vs `main`, merge base `bf16a1f`)
- **Date:** 2026-11-13
- **Reviewer:** Rebuild correctness
- **Slug:** `rebuild-correctness`
- **Role:** Check reproducibility, script behavior, dependency boundaries and evidence.

## Summary

The branch adds a standalone React Native 0.86.0 iOS probe in `spikes/ios-updates/`
and a qualification record in `docs/qualification/ios-updates.md`. The record
supports a v1 decision: every customization, including a JS-only change, needs a
Release rebuild and reinstall. `prepare.sh` generates the community template into
the ignored `.work/` directory, then installs the committed `package-lock.json` and
`Podfile.lock`. `rebuild.sh` writes revision A or B into `index.js`, builds Release
for a simulator with signing disabled, installs, launches, and hashes the embedded
`main.jsbundle`. The retained evidence (screenshots, compressed build, prepare, and
verify logs, bundle hashes) is committed.

## What I verified (without rerunning native builds)

- **Screenshots:** `A.png` and `no-rebuild.png` show "AgentUI update probe A".
  `B.png` and `B-restart.png` show "B". The no-rebuild screenshot is consistent with
  `.work/app-first/index.js`, which still contains the B text. This is the tree that
  was edited without a rebuild.
- **Builds:** the uncompressed `.work/evidence/build-{A,B}.log` files both end in
  `** BUILD SUCCEEDED **` and run `react-native-xcode.sh`, so the bundle is embedded.
  The "Bundle React Native code and images" phase has no declared outputs, so it runs
  on every build. Incremental rebuilds therefore re-bundle reliably.
- **Bundle hashes:** the A and B bundle hashes differ (`b95de99c…` vs `1fe9fe31…`).
- **Locks:** the committed `Podfile.lock` is byte-identical to the lock in both
  `.work/app/ios` and `.work/app-first/ios`. The committed `package-lock.json` is
  identical to `.work/app/package-lock.json`. `Podfile.lock` records
  `COCOAPODS: 1.16.2` and `hermes-engine (250829098.0.14)`, matching the doc.
- **Dependency boundary:** `react` is 19.3.1 and `react-native` is 0.86.0, matching
  `apps/ios/package.json`. `spikes/` is outside the root `workspaces` and the root
  `lint` globs, so the main workspace lock is untouched.
- **Commit split:** `b4258d6` contains every script and lock. `e4f3a96` only adds
  docs and evidence, so citing `b4258d6` as the "Probe implementation source" is
  accurate.
- **Limitation:** I could not decompress `prepare-clean.log.gz` or `verify.log.gz`
  in this session because decompression needed approval I didn't have. The
  "Pinned dependency installation", "Fresh template preparation", and "npm run
  verify" rows are therefore checked only indirectly, through the lock matches above.

## Verdict: **REQUEST_CHANGES** (small scope)

The qualification claims are supported by the evidence. The blockers are about
whether the probe stays reproducible. `prepare.sh` does not make CocoaPods honor the
committed lock: the lock is optional, and `pod install` runs without `--deployment`.
A rerun can therefore re-resolve pods silently and still report success, which
undercuts the doc's "Pinned … dependencies" claim. The committed evidence also
contains absolute home-directory paths. Both fixes are a few lines each.

## Stats

- Files changed: 18. Of these, 2 are lockfiles and 9 are binary or evidence files.
- Lines: +8515 / −0. About 8306 of the added lines are lockfiles.
- Commits: 2 (`b4258d6`, `e4f3a96`)
