# Action Items

Branch `codex/ios-update-qualification` @ `e4f3a963ccce` — reviewer: Rebuild correctness (`rebuild-correctness`). Verdict: REQUEST_CHANGES (small scope).

## Action Items

### Critical
- (none)

### Important
- [ ] [spikes/ios-updates/prepare.sh:14-16] Fail if the committed `Podfile.lock` is missing (drop the `if [[ -f ... ]]` guard). Run `pod install --deployment`, then add `cmp -s Podfile.lock .work/app/ios/Podfile.lock || exit 1` so drift in the template Podfile or the pods cannot silently re-resolve. Add a `pod --version == 1.16.2` check next to the Node/npm checks.
- [ ] [spikes/ios-updates/rebuild.sh:36] Hash from inside the product directory, `(cd "$product" && shasum -a 256 main.jsbundle) > ...`, so the evidence has no absolute paths. Rewrite `evidence/bundle-A.sha256` and `evidence/bundle-B.sha256` to `<hash>  main.jsbundle`. The hash values stay the same: A `b95de99c…99808`, B `1fe9fe31…c89f0`.
- [ ] [spikes/ios-updates/evidence/build-A.log.gz, build-B.log.gz] Either redact `$HOME` (`sed "s#$HOME#~#g"`) before compressing and recommit, or explicitly accept that local username and paths are published.

### Suggestions
- [ ] [spikes/ios-updates/rebuild.sh:36] After the build, assert `grep -aq "AgentUI update probe $revision" "$product/main.jsbundle"` so the embedded revision is machine-checked.
- [ ] [docs/qualification/ios-updates.md:63,66] Commit evidence files for the no-rebuild source state (the `index.js` text or its hash) and the empty `lsof -nP -iTCP:8081 -sTCP:LISTEN` result, so every PASS row has a matching artifact.
- [ ] [docs/qualification/ios-updates.md:57-66] Add a sentence saying B was built from the freshly prepared tree (the first tree was moved aside), reusing `.work/build` derived data.
- [ ] [spikes/ios-updates/prepare.sh:16] Pin the Ruby and CocoaPods toolchain (commit a `Gemfile.lock` and use `bundle exec pod`), or document that the global `pod` ignores the template Gemfile constraints.
- [ ] [spikes/ios-updates/prepare.sh:9-10] Record a checksum of the generated `ios/` project files (Podfile, `project.pbxproj`, `AppDelegate.swift`) to detect template drift from the unlocked `npx` init.
- [ ] [spikes/ios-updates/rebuild.sh:26-30] When xcodebuild fails, print the tail of the log and its path instead of exiting silently.
- [ ] [spikes/ios-updates/rebuild.sh:5] Check that the simulator is booted (`xcrun simctl list devices | grep "$simulator) (Booted)"`) before building.
- [ ] [spikes/ios-updates/rebuild.sh:13] Use a quoted heredoc with explicit substitution, or add a comment that the unquoted expansion is intentional.
