# Suggestions

### S1. Check the bundle contents automatically, not only by screenshot
**File:** `spikes/ios-updates/rebuild.sh:36`
The script hashes the bundle but never checks that the bundle holds the requested revision. A stale embedded bundle would still produce a hash, and only a human looking at the screen would catch it. Hermes bytecode keeps string literals in its string table, so a byte-level grep works:
```bash
grep -aq "AgentUI update probe $revision" "$product/main.jsbundle" || {
  echo "Embedded bundle does not contain revision $revision." >&2; exit 1; }
```
This does not replace visual acceptance. It gives the scripts a machine-checked part of "B was embedded".

### S2. Keep the "no Metro" and "source edited" claims as files
**Files:** `docs/qualification/ios-updates.md:63,66`, `spikes/ios-updates/README.md:28-45`
The "no listener on 8081" claim and the fact that `index.js` held B during the no-rebuild check are stated in the docs but not stored in `evidence/`. I confirmed the source edit only through the ignored `.work/app-first/index.js`. Add two small files, such as `evidence/no-rebuild-source.sha256` (or the `index.js` text) and `evidence/metro-8081.txt` with the `lsof` output or a note that it was empty plus the exit code. That way every PASS row has a matching committed artifact.

### S3. Say that B was built from a freshly prepared tree
**File:** `docs/qualification/ios-updates.md:57-66`
A was built from the first generated tree, which was later moved to `.work/app-first`. B was built after the "fresh template preparation" step, from a regenerated tree that reused the same `.work/build` derived data. The conclusion still holds. But someone reading the table could think B was an incremental rebuild of the same tree after a JS-only edit. One sentence fixes this, for example "B was built from the fresh-prepare tree; the bundle phase runs every build."

### S4. Ruby gem versions are not pinned
**File:** `spikes/ios-updates/prepare.sh:16`
The generated template ships a `Gemfile` that constrains `xcodeproj < 1.26.0`, `activesupport`, and other gems. The script instead runs the global `pod`, which ignores those constraints, and no `Gemfile.lock` is committed. Either document that the global CocoaPods 1.16.2 install is the source of truth, or commit a `Gemfile.lock` and use `bundle exec pod install`.

### S5. The template download is not locked
**File:** `spikes/ios-updates/prepare.sh:9-10`
`npx --yes @react-native-community/cli@20.2.0` pins the top-level CLI only. Its transitive dependencies and the template package come from the registry at run time. The I1 fix catches drift that reaches the Podfile. For broader drift, record a checksum of the generated `ios/` project files (Podfile, `project.pbxproj`, `AppDelegate.swift`) in `evidence/`.

### S6. Show the build log on failure
**File:** `spikes/ios-updates/rebuild.sh:26-30`
All xcodebuild output goes to the log. With `set -e`, a failed build exits silently. Print the tail of the log and its path:
```bash
if ! xcodebuild ... > "$log" 2>&1; then
  tail -n 40 "$log" >&2; echo "Build failed; see $log" >&2; exit 1
fi
```

### S7. Fail fast when the simulator is not booted
**File:** `spikes/ios-updates/rebuild.sh:5`
Check the state before spending minutes on the build:
```bash
xcrun simctl list devices | grep -q "$simulator) (Booted)" || { echo 'Boot the simulator first.' >&2; exit 1; }
```

### S8. Quote the heredoc and substitute explicitly
**File:** `spikes/ios-updates/rebuild.sh:13`
The unquoted `<<JS` expands any `$` or backtick that might later appear in the JS. It is safe today because `revision` is validated as A or B. If the JS is ever extended, use `<<'JS'` with a placeholder and `sed`, or keep the current form and add a comment saying it is deliberate.
