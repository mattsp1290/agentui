# Positive Notes

- **Honest scope limits.** `docs/qualification/ios-updates.md:11-13,68-70` marks live
  updates, physical-device signing and integrated AgentUI as UNQUALIFIED. Line 22-23 says
  live delivery is "unqualified, not demonstrated impossible". Records like this tend to
  overclaim, and this one avoids it.
- **Visual acceptance is not automated away.** README line 25-26 and doc line 73-74 say
  that a successful build or launch does not prove rendering. The screenshots were
  retained, and I inspected them: A, still A after the source edit, B, and B after restart.
- **Release path is evidenced in the logs.** `build-A.log`/`build-B.log` show
  `bundle.js ... --dev false` followed by `hermesc -emit-binary -O -out .../AgentUIUpdateProbe.app/main.jsbundle`.
  That shows the embedded bytecode bundle, not a Metro URL, is what ships. The two hashes
  differ (`b95de99c…` vs `1fe9fe31…`).
- **Isolation from the product workspace.** The probe has its own `package.json`/lock, is
  not in root `workspaces`, and keeps all generated output under the ignored `.work/`
  (`spikes/ios-updates/.gitignore`). The main lockfile and `apps/ios` are untouched.
- **Versions match the repository pins.** `react@19.3.1` / `react-native@0.86.0` in
  `spikes/ios-updates/package.json` match `apps/ios/package.json:22-23`, and Node/npm
  match `boundaries.md:74`.
- **Defensive scripts.** `rebuild.sh:4-6` validates `A|B` before interpolating it into the
  heredoc, so arbitrary input is never injected into JS. `set -euo pipefail`, the
  toolchain version gate and the "Run prepare.sh first" guard all fail fast.
- **Environment table.** `ios-updates.md:35-50` records macOS build, Xcode build, SDK vs
  runtime, simulator UDID, Hermes version and signing mode, which meets
  `apple-qualification.md:11`'s required fields.
