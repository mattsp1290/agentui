# Action Items

Reviewer: Qualification skeptic (`qualification-skeptic`) · Branch `codex/ios-update-qualification` @ `e4f3a963ccce` · Verdict: REQUEST_CHANGES

## Action Items

### Critical
- (none)

### Important
- [ ] [docs/qualification/ios-updates.md:66] The "B restart without Metro" row cites "no listener on 8081", but no `lsof` output was retained. Either commit the check output (`evidence/metro-8081.txt`, and an AppDelegate `bundleURL` excerpt for README:42-45), or reword the row to cite the build-B log's `--dev false` + hermesc embed and mark the 8081 check "performed, not retained".
- [ ] [docs/qualification/ios-updates.md:63,66; spikes/ios-updates/README.md:28-35] The no-rebuild and restart PASS rows have no evidence that `index.js` said B or that the app was relaunched (`no-rebuild.png` looks the same as `A.png`). Add a scripted restart step that records the source label, installed-bundle hash and new launch pid to `evidence/restart-*.txt`, or label these rows "operator-attested".
- [ ] [spikes/ios-updates/prepare.sh:9-16; docs/qualification/ios-updates.md:61,64] Lock fidelity is not enforced. Use `pod install --deployment`, then `cmp Podfile.lock .work/app/ios/Podfile.lock`, and add a `pod --version == 1.16.2` gate. Remove or explain the line-14 "freeze after first resolution" comment. Reword row 64, because RN artifact caches were warm (`prepare-clean.log` "Cache hit") and `.work/build` survives a "fresh" prepare.
- [ ] [docs/qualification/ios-updates.md:75; spikes/ios-updates/rebuild.sh:36] The doc says the "installed bundle" is under `.work/`, but `rebuild.sh` hashes the build product, not the installed app. Hash `$(xcrun simctl get_app_container "$simulator" "$bundle_id")/main.jsbundle` with a relative filename (this also removes the absolute home path from `bundle-*.sha256`), and fix the doc sentence.
- [ ] [docs/architecture/boundaries.md:96-97; docs/architecture/apple-qualification.md:15; docs/qualification/ios-updates.md:24] Reconcile the decision with the architecture docs. `boundaries.md` still lists Expo as an update option, and `apple-qualification.md` scopes rebuild-required to native-incompatible changes only. Link both to the new record and name or link the task behind "the task's accepted v1 alternative".

### Suggestions
- [ ] [docs/qualification/ios-updates.md:67] Clarify that `npm run verify` is a regression check that excludes `spikes/`. Optionally run and record `shellcheck spikes/ios-updates/*.sh`.
- [ ] [spikes/ios-updates/README.md:6-8; docs/qualification/ios-updates.md:45] Document how `/tmp/agentui-ios-tools` (the Node used in the build logs) was provisioned.
- [ ] [spikes/ios-updates/rebuild.sh:26-30] Write `git rev-parse HEAD` and `xcodebuild -version` at the top of each build log, so the evidence is tied to the stated probe revision.
- [ ] [spikes/ios-updates/rebuild.sh:37-38] Add a `collect.sh` that gzips logs, replaces `$HOME` with `~`, and copies the results into `evidence/`. This keeps personal absolute paths out of committed artifacts.
- [ ] [spikes/ios-updates/rebuild.sh:5] Fail early when the target simulator is not booted (`xcrun simctl list devices booted | grep -q "$simulator"`).
- [ ] [spikes/ios-updates/prepare.sh:12] Add a comment saying the template's `package.json` scripts and dev dependencies are dropped on purpose.
- [ ] [spikes/ios-updates/rebuild.sh:36] On B, compare against `bundle-A.sha256` and fail when the hashes match, to catch stale bundles automatically.
