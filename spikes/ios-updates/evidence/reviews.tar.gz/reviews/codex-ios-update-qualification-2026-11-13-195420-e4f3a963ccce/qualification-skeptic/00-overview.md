# Review Overview

- **Branch:** `codex/ios-update-qualification`
- **Head:** `e4f3a963ccce848e2e8c4e3d7d5337e53acb16c1` (base `main`, merge-base `bf16a1f`)
- **Date:** 2026-11-13
- **Reviewer:** Qualification skeptic
- **Reviewer slug:** `qualification-skeptic`
- **Role:** Independently challenge acceptance claims, missing cases and maintainability.

## Summary

The branch adds a standalone React Native 0.86.0 probe under `spikes/ios-updates/`
(`prepare.sh` generates the community template and installs committed npm and CocoaPods
locks; `rebuild.sh` writes an A/B `index.js`, builds Release for the simulator with
`CODE_SIGNING_ALLOWED=NO`, installs, launches and hashes `main.jsbundle`). It also adds a
qualification record (`docs/qualification/ios-updates.md`) that selects rebuild-only iOS
updates for v1, plus retained evidence: four screenshots, gzipped build/prepare/verify logs,
and two bundle hashes.

The core claim holds up against the evidence I could inspect. Both build logs show the
"Bundle React Native code and images" phase running `bundle.js --dev false`, then `hermesc`
writing into `AgentUIUpdateProbe.app/main.jsbundle`, then `** BUILD SUCCEEDED **`. The two
bundle hashes differ (`b95de99c…` vs `1fe9fe31…`). Screenshots `A.png`, `no-rebuild.png`,
`B.png` and `B-restart.png` show the expected labels. The record also labels live updates,
physical devices and integrated AgentUI as UNQUALIFIED, which is honest.

Several rows marked PASS lack retained evidence, though, or have a weaker basis than the
table suggests:
- The table claims no listener on port 8081, but no `lsof` output was kept.
- The no-rebuild and restart rows rest on screenshots that look the same as the earlier
  screenshots. Nothing proves that the source was edited or that the app was relaunched.
- The lock-fidelity row relies on `pod install`, which does not fail on drift, and the
  resulting lock is never compared with the committed one.

The doc also says the installed bundle is under `.work/`, which is wrong. And the decision
conflicts with `docs/architecture/boundaries.md`, which still says "Expo remains an option
for developer installation and updates." None of this is a crash or a security defect. But
this is a qualification record, and its value comes from claims that can be audited.

## Verdict

**REQUEST_CHANGES**: no Critical issues. There are 4 Important issues about the accuracy of
acceptance claims and the evidence behind them, plus one documentation consistency issue.
Most can be fixed by downgrading or rewording rows rather than rerunning native builds.

## Stats

- Files changed: 18 (12 text, 6 binary evidence: 4 PNG, 4 `.log.gz` — of which 2 lockfiles are generated)
- Lines: +8515 / −0 (≈8306 of that is `package-lock.json` + `Podfile.lock`)
- Commits: 2 (`b4258d6` probe, `e4f3a96` record + evidence)
