# Suggestions

### S1. The "Repository npm run verify" row does not cover the spike

- **File:** `docs/qualification/ios-updates.md:67`
- `npm run verify` runs `oxlint packages apps scripts` and workspace builds. `spikes/` is
  not a workspace and is not linted, and nothing checks the shell scripts. The PASS row is
  true, but a reader could take it as verification of the probe. Suggested wording:

  ```md
  | Repository npm run verify (regression, excludes spikes/) | PASS | 11 tests, build, check, lint |
  ```

  Consider running `shellcheck spikes/ios-updates/*.sh` and recording the result.

### S2. Document the isolated Node toolchain the logs actually used

- **Files:** `spikes/ios-updates/README.md:6-8`, `docs/qualification/ios-updates.md:45`
- Both build logs run `/tmp/agentui-ios-tools/node_modules/.bin/node`. The doc says only
  "isolated tools on PATH". Add one line explaining how that directory was provisioned
  (e.g. `npm i --prefix /tmp/agentui-ios-tools node@24.22.3 npm@11.19.1`), so someone else
  can reproduce the environment.

### S3. Record the source revision in the evidence

- **Files:** `spikes/ios-updates/rebuild.sh:12-30`
- The doc names `b4258d6` as the probe source, but nothing in the logs ties a build to that
  commit. Prefix the build log with the commit:

  ```sh
  { echo "source: $(git rev-parse HEAD)"; xcodebuild -version; } > ".work/evidence/build-$revision.log"
  xcodebuild ... >> ".work/evidence/build-$revision.log" 2>&1
  ```

### S4. Script the evidence collection

- **Files:** `spikes/ios-updates/rebuild.sh:37-38`, README
- Screenshots, gzip and copying into `evidence/` were done by hand. A small `collect.sh`
  that gzips `.work/evidence/*.log`, strips `$HOME` from paths
  (`sed "s#$HOME#~#g"`), and copies files into `evidence/` would make reruns cheaper and
  keep personal paths out of committed artifacts. The current logs embed
  `/Users/<user>/...` throughout.

### S5. Check the simulator state before building

- **File:** `spikes/ios-updates/rebuild.sh:5,26-28`
- When the simulator is not booted, `simctl install`/`launch` fail late, after a
  multi-minute build. Fail early instead:

  ```sh
  xcrun simctl list devices booted | grep -q "$simulator" || { echo 'Boot the simulator first.' >&2; exit 1; }
  ```

### S6. Note what `prepare.sh` drops from the template's package.json

- **File:** `spikes/ios-updates/prepare.sh:12`
- Overwriting the template's `package.json` removes its scripts and its lint, test and
  TypeScript dev dependencies. This is intentional and harmless here, but a one-line
  comment would stop a future editor from "fixing" it.

### S7. Add a bundle-identity check between A and B

- **File:** `spikes/ios-updates/rebuild.sh:36`
- After building B, compare against A's hash and fail when they match. That catches a
  stale bundle without relying on someone looking at the screenshot.
