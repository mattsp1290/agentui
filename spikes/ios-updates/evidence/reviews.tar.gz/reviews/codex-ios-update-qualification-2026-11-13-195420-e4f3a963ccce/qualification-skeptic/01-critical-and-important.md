# Critical and Important Issues

## Critical

None found. The scripts are small, they run under `set -euo pipefail`, and they validate
the revision argument before interpolating it into the heredoc. The build evidence I
inspected supports the central simulator rebuild claim.

## Important

### I1. "No listener on 8081" is claimed as PASS with no retained evidence

- **Severity:** Important
- **Files:** `docs/qualification/ios-updates.md:66`, `spikes/ios-updates/README.md:42-45`
- **Problem:** The "B restart without Metro" row cites "B-restart screenshot, no listener on
  8081". Only the screenshot was retained. A screenshot cannot show the absence of a Metro
  listener, so the "without Metro" half of the row is asserted, not evidenced. The README
  also says the `lsof` check "plus the Release bundle URL in generated AppDelegate.swift
  confirms" independence from Metro, but neither the `lsof` output nor the AppDelegate
  excerpt is in `evidence/`.

  The build logs do give strong indirect evidence: `--dev false` and `hermesc -emit-binary`
  writing into the `.app`. The doc should cite that evidence instead of evidence it does not
  have.
- **Suggested fix:** Either retain the check output, or reword the row to cite what exists:

  ```sh
  # during qualification, before the B restart
  lsof -nP -iTCP:8081 -sTCP:LISTEN > .work/evidence/metro-8081.txt 2>&1 || echo "exit=$? (no listener)" >> .work/evidence/metro-8081.txt
  grep -n 'main.jsbundle\|bundleURL' .work/app/ios/AgentUIUpdateProbe/AppDelegate.swift > .work/evidence/bundle-url.txt
  ```

  ```md
  | B restart without Metro | PASS | B-restart screenshot; build-B log shows `--dev false` bundle embedded by hermesc. 8081 check performed, output not retained |
  ```

### I2. The no-rebuild and restart rows have no evidence that the precondition happened

- **Severity:** Important
- **Files:** `docs/qualification/ios-updates.md:63,66`, `spikes/ios-updates/README.md:28-35,42`
- **Problem:** `no-rebuild.png` looks the same as `A.png`. Both even show the same status-bar
  minute (7:52), so the edit, terminate and relaunch all had to fit inside that minute.
  `B-restart.png` (7:54) looks the same as `B.png` (7:53). The PASS result for "Source edit to B without
  rebuild, then restart → still A" depends on two manual steps that left no trace: that
  `.work/app/index.js` actually said B, and that `simctl terminate`/`launch` actually ran.
  If either step were skipped, the screenshot would look the same, so the row cannot tell a
  real pass from a skipped step. This is the most important negative control in the record,
  and it rests on no evidence.
- **Suggested fix:** Script the control so that it records its own preconditions. For
  example, add a `no-rebuild` mode to `rebuild.sh` (or a small `restart.sh`):

  ```sh
  # spikes/ios-updates/restart.sh <label> <udid>
  set -euo pipefail
  cd "$(dirname "$0")"
  bundle_id=org.reactjs.native.example.AgentUIUpdateProbe
  {
    echo "source: $(grep -o "update probe [AB]" .work/app/index.js)"
    echo "installed: $(shasum -a 256 "$(xcrun simctl get_app_container "$2" "$bundle_id")/main.jsbundle" | cut -d' ' -f1)"
    xcrun simctl terminate "$2" "$bundle_id" || true
    echo "launch: $(xcrun simctl launch "$2" "$bundle_id")"   # prints a new pid
  } | tee ".work/evidence/restart-$1.txt"
  ```

  Commit `restart-no-rebuild.txt` and `restart-B.txt` next to the screenshots. Until then,
  annotate the rows as "operator-attested".

### I3. "Pinned dependency installation" / "Fresh preparation with committed locks" overstates what `pod install` enforces

- **Severity:** Important
- **Files:** `spikes/ios-updates/prepare.sh:9-16`, `docs/qualification/ios-updates.md:52-55,61,64`
- **Problem:**
  1. `pod install` treats `Podfile.lock` as a preference. It re-resolves and silently
     rewrites the lock when the Podfile or podspecs disagree with it. It never fails on
     drift. Nothing compares `.work/app/ios/Podfile.lock` after the install with the
     committed `Podfile.lock`, so "pinned" and "with committed locks" are not verified.
     (`npm ci` does enforce its lock, so the npm half is fine.)
  2. `npx --yes @react-native-community/cli@20.2.0` resolves the CLI's transitive
     dependencies and the `@react-native-community/template` tarball from the registry at
     run time. Neither is integrity-pinned, so the generated Podfile and native template
     are not covered by any committed lock.
  3. `prepare.sh` checks Node and npm versions but not `pod --version`, although the README
     and doc pin CocoaPods 1.16.2.
  4. `prepare-clean.log` shows ReactNative, Hermes and core tarballs coming from
     `~/Library/Caches/ReactNative` ("Cache hit"). "Fresh" means a fresh template, not a
     cold dependency fetch, and moving `.work/app` aside leaves `.work/build` (DerivedData)
     in place (README line 49-50).
  5. The comment "Freeze native dependencies after the first measured pod resolution" on
     line 14 describes a bootstrap path (no committed lock) that cannot write the lock
     back. It is dead, misleading guidance.
- **Suggested fix:**

  ```sh
  [[ "$(pod --version)" == 1.16.2 ]] || { echo 'Use CocoaPods 1.16.2.' >&2; exit 1; }
  ...
  cp Podfile.lock .work/app/ios/
  (cd .work/app/ios && pod install --deployment)
  cmp Podfile.lock .work/app/ios/Podfile.lock   # fail if CocoaPods rewrote the lock
  ```

  Reword doc row 64 to "Fresh template generation with committed locks (shared RN artifact
  cache warm; DerivedData retained)". Either delete the line-14 comment or document how the
  lock was first produced.

### I4. The doc says the installed bundle is in `.work/`, but it is in the simulator container

- **Severity:** Important (incorrect qualification claim)
- **Files:** `docs/qualification/ios-updates.md:74-75`, `spikes/ios-updates/rebuild.sh:36`,
  `spikes/ios-updates/evidence/bundle-{A,B}.sha256`
- **Problem:** Line 75 says the "installed bundle" is under `.work/`. `rebuild.sh` hashes
  the build product
  (`.work/build/Build/Products/Release-iphonesimulator/AgentUIUpdateProbe.app/main.jsbundle`),
  not the installed copy inside the simulator's data container. The two hashes therefore
  show that the build output changed, not that the installed app changed. The
  installed-update claim rests only on screenshots. The `.sha256` files also include an
  absolute home-directory path, which ties the evidence to one machine and user.
- **Suggested fix:**

  ```sh
  installed="$(xcrun simctl get_app_container "$simulator" "$bundle_id")"
  (cd "$installed" && shasum -a 256 main.jsbundle) > ".work/evidence/bundle-$revision.sha256"
  ```

  Then change the doc to "Full local build output and the generated app are under ignored
  `.work/`; installed-bundle hashes are in evidence."

### I5. The decision conflicts with the architecture docs and is not cross-linked

- **Severity:** Important (documentation consistency for an accepted decision)
- **Files:** `docs/qualification/ios-updates.md:3-9,15-24`,
  `docs/architecture/boundaries.md:96-97`, `docs/architecture/apple-qualification.md:15`
- **Problem:** `boundaries.md:96` still says "Expo remains an option for developer
  installation and updates", and line 97 says "Mac-delivered committed updates require
  separate qualification". The new record decides rebuild-only and explicitly excludes
  Expo, but neither architecture doc points to it. `apple-qualification.md:15` scopes
  rebuild-required to *native-incompatible* customization, while the new decision makes
  *every* change rebuild-required. That broadening may be right, but it should be stated
  where future readers will look. Line 24 also cites "the task's accepted v1 alternative"
  without naming or linking the task.
- **Suggested fix:**

  ```md
  <!-- boundaries.md -->
  iOS v1 uses rebuild-only updates; see [iOS update qualification](../qualification/ios-updates.md).
  Expo and live delivery remain unqualified options for later versions.
  ```

  ```md
  <!-- apple-qualification.md:15 -->
  For v1, every iOS customization change reports rebuild-required ([decision](../qualification/ios-updates.md)).
  ```
