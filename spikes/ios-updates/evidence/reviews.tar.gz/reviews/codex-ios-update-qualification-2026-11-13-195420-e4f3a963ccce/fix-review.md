# Fix review against e4f3a963ccce on codex/ios-update-qualification

All ten reviewer files read; branch and head matched before fixes. Source fixes are 230f062 and 7d250ae.

- Fixed shared native lock finding: mandatory lock, CocoaPods 1.16.2 check, deployment install, byte comparison. Deployment install passed.
- Fixed evidence findings: installed bundle hashes with relative names; restart.sh retains source label, hash, lsof result and launch PID. Repeated A/no-rebuild/B journey after changes.
- Fixed path portability: logs redacted before retaining, hashes now relative. Earlier commits contain local paths, which are not credentials.
- Fixed qualification wording: build output versus simulator installation, warm cache versus fresh template, regression suite excludes spike, global pod versus template Gemfile, task ID and bootstrap limits documented.
- Architecture cross-links deferred to the designated Linux integration owner, outside the reserved files. Existing docs describe unqualified future options, so they do not claim an implemented conflicting updater. Qualification doc now explicitly states recommendation scope. Return handoff requests integration cross-links.
- Suggestions accepted: source SHA/build version in logs, simulator boot guard, embedded revision assertion, Node setup recipe, native template checksums, deliberate heredoc comment, minimal dependency-set comment.
- Optional collect.sh and A/B hash-comparison abstraction omitted: embedded revision assertion plus installed readback and retained hashes cover stale bundles; evidence collection is a bounded operator step. No production API is added.
- Optional automatic failure-log tail omitted: exact per-revision log paths are documented and retained; set -e preserves failure. No crash or security defect depends on it.
