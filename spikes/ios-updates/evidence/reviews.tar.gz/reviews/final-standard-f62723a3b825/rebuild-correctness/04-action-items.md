# Action Items

- **Branch:** `codex/ios-update-qualification` @ `f62723a3b825`
- **Reviewer:** Rebuild correctness (`rebuild-correctness`)
- **Verdict:** APPROVE

## Action Items

### Critical
- (none)

### Important
- (none). Prior I1 (CocoaPods lock enforcement) and I2 (absolute paths in evidence) are both fixed and verified.

### Suggestions
- [ ] [spikes/ios-updates/restart.sh:23] Append `2>/dev/null || true` to `xcrun simctl terminate`, as `rebuild.sh:39` already does. Without it, restart.sh fails and leaves a partial restart log when the app is not running.
- [ ] [spikes/ios-updates/restart.sh:7] Read the bundle ID from the built product's `Info.plist`, as `rebuild.sh:37` does, instead of hardcoding `org.reactjs.native.example.AgentUIUpdateProbe`.
- [ ] [spikes/ios-updates/README.md:24-26] Document the redaction step used before retaining a log, `sed "s#$HOME#~#g" .work/evidence/build-X.log | gzip -9 > evidence/build-X.log.gz`, so the next operator doesn't commit raw home paths.
- [ ] [spikes/ios-updates/rebuild.sh:29, restart.sh:10] Record whether the working tree is dirty (`git describe --always --dirty` or `git status --porcelain -- .`) next to the SHA.
- [ ] [spikes/ios-updates/rebuild.sh:30-34] Optional, and declined earlier: print the log tail when xcodebuild fails.
