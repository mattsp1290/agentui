# Positive Notes

- **Fail-closed native lock** (`prepare.sh:17-19`): copying the lock unconditionally, running `pod install --deployment`, and then running `cmp` is the strictest practical way to pin CocoaPods. A missing lock, a template Podfile that drifts, or a lock that gets rewritten each stop the script.
- **Exact toolchain gates** (`prepare.sh:4-7`, `rebuild.sh:7-9`): Node, npm, and CocoaPods must match exact versions before any work starts. `package.json` repeats the Node and npm versions in `engines`.
- **Proof from what is installed, not what was built** (`rebuild.sh:36,41-42`, `restart.sh:12-14`):
  - The script asserts the revision string in the built `main.jsbundle`.
  - It then hashes the copy inside the simulator's app container.
  - Hashing the container proves what the simulator is actually running.
  - Because hashing happens inside that directory, the evidence contains no host paths.
- **The no-rebuild case is proven by mismatch** (`evidence/restart-no-rebuild.txt`): the source label is B while the installed hash is A's `b95de99c…`. That pairing directly shows that editing the source does not change the installed Release app.
- **The Metro check is honest** (`restart.sh:16-22`): `lsof` exit 1 is treated as "no listener". Any other `lsof` failure, or an actual listener, aborts instead of producing a false PASS.
- **Revision input is validated before the unquoted heredoc** (`rebuild.sh:6,14-15`), and a comment explains why the expansion is intentional.
- **Clear isolation:** generated output lives in the ignored `.work/`, and the probe keeps its own dependency tree outside the root workspaces. The doc marks live updates, physical devices, and integrated behavior as UNQUALIFIED instead of overclaiming.
- **Evidence ties back to source:** each build log starts with the source SHA and the Xcode version, and the doc names `7d250ae` as the probe source. The logs confirm that SHA.
