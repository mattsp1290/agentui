# Critical and Important Issues

## Critical

None.

## Important

None.

Both earlier Important findings are resolved in the current source:

- **Prior I1 (CocoaPods lock not enforced):** fixed in `spikes/ios-updates/prepare.sh:7,17-19`.
  - The required CocoaPods version is checked.
  - The lock copy is unconditional, so with `set -e` the script fails if the lock is missing.
  - `pod install --deployment` refuses to run when the Podfile and the lock disagree.
  - `cmp` fails if the lock was rewritten.

  The retained `prepare-deployment.log.gz` shows a successful deployment install, and the generated lock is byte-identical to the committed one.
- **Prior I2 (absolute paths in evidence):** fixed.
  - Both hash files are relative (`main.jsbundle`).
  - Both scripts hash from inside the installed app container.
  - The retained `build-A.log.gz`, `build-B.log.gz`, and `prepare-deployment.log.gz` each contain 0 occurrences of `/Users/`.

I also checked the new control flow in `restart.sh`:

- The `{ … } | tee` group runs in a subshell. `set -e` is inherited there, and `pipefail` carries a failure inside the group to the script, which then exits.
- In the `else` branch of `if lsof …`, `$?` holds the exit status of `lsof`. Status 1 is accepted as "no listener", and any other status propagates.

No defect found.
