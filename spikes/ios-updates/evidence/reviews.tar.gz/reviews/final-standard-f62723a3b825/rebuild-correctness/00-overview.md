# Review Overview

- **Branch:** `codex/ios-update-qualification`
- **Head:** `f62723a3b825ffb78d4552b5a9109b94fc73e0e5` (base `main`)
- **Date:** 2026-11-13
- **Reviewer:** Rebuild correctness
- **Slug:** `rebuild-correctness`
- **Role:** Check reproducibility, script behavior, dependency boundaries and evidence. This pass is the final reassessment of the earlier findings (`reviews/codex-ios-update-qualification-2026-11-13-195420-e4f3a963ccce/rebuild-correctness`) against the fixes in that run's `fix-review.md`.

## Summary

The branch adds a standalone React Native 0.86.0 iOS probe in `spikes/ios-updates/` and a
qualification record in `docs/qualification/ios-updates.md`. The record recommends
rebuild-only updates for v1. The probe has three scripts:

- `prepare.sh` generates the template, then installs the committed npm and CocoaPods locks in deployment mode and fails on lock drift.
- `rebuild.sh` writes revision A or B, builds Release for the simulator, checks that the embedded bundle contains the revision, installs and launches the app, and reads the bundle hash back from the installed app.
- `restart.sh` records the source label, the installed bundle hash, and the result of the Metro port check, then relaunches the app.

Since `7d250ae`, the scripts and locks are unchanged. `f62723a` adds only docs and evidence; `git diff --stat 7d250ae f62723a` over the scripts and locks is empty.

## Prior findings, revalidated

| Prior item | Status | Verification |
| --- | --- | --- |
| I1: CocoaPods lock was not enforced | **Fixed** | `prepare.sh:7,17-19` checks for CocoaPods 1.16.2, copies the lock unconditionally (so `set -e` fails if it is missing), runs `pod install --deployment`, and fails on `cmp`. `prepare-deployment.log.gz` ends in "Pod installation complete! … 75 total pods". The generated `.work/app/ios/Podfile.lock` is byte-identical to the committed lock. |
| I2: absolute home paths in evidence | **Fixed** | Both `bundle-*.sha256` files now record `<hash>  main.jsbundle`. `rebuild.sh:42` and `restart.sh:14` hash relative to the installed container. Retained build and prepare logs contain 0 occurrences of `/Users/`; paths appear as `~/…`. The paths in earlier commits are history only and are not credentials, which the fix log acknowledges. |
| S1: embedded revision assertion | Fixed | `rebuild.sh:36` |
| S2: no-rebuild source and Metro evidence | Fixed | `restart-no-rebuild.txt` shows source label B with the installed A hash `b95de99c…`, plus `lsof exit 1`. `restart-B.txt` shows the B hash `1fe9fe31…`. Both match `bundle-{A,B}.sha256`. |
| S3: tree provenance wording | Fixed | Doc lines 79-82 |
| S4: global pod versus Gemfile | Documented | README line 48 |
| S5: template drift checksums | Fixed | `evidence/native-template.sha256` |
| S6: show the log tail on failure | Declined with a reason | Acceptable. The build still fails non-zero, and the log path is deterministic. |
| S7: simulator boot guard | Fixed | `rebuild.sh:10` |
| S8: heredoc comment | Fixed | `rebuild.sh:14` |

## Evidence spot checks

- The build-A and build-B logs both start with source SHA `7d250ae…` and Xcode 26.2 (17C52), end in `** BUILD SUCCEEDED **`, and run `react-native-xcode.sh`.
- The A, no-rebuild, B, and B-restart screenshots match the claims. `no-rebuild.png` shows A, and `B-restart.png` shows B.
- `verify.log.gz` shows 11 tests with 11 passing and 0 failing.
- The generated `AppDelegate.swift` Release `bundleURL()` loads `main.jsbundle`, which is consistent with the doc's claim that the app does not need Metro.

## Verdict: **APPROVE**

Both Important findings are fixed and verified, and every suggestion was either applied or declined with a sound reason. I found no new defect in the resulting source that breaks correctness or reproducibility. The remaining items in `02-suggestions.md` are optional robustness polish. The architecture cross-links are reserved for the Linux integration owner, and the record explicitly limits itself to a recommendation, so they are out of scope here. The two large lockfiles are generated dependency records and should stay intact.

## Stats

- Files changed: 24. Of these, 2 are generated lockfiles and 13 are evidence files, binary or text.
- Lines: +8590 / −0. About 8306 of the added lines are lockfiles, and the handwritten scripts total 89 lines.
- Commits: 5 (`b4258d6`, `e4f3a96`, `230f062`, `7d250ae`, `f62723a`)
