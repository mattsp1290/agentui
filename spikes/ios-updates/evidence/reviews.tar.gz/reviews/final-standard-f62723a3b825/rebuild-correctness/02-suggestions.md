# Suggestions

None of these block merging. Each one is an optional robustness improvement, not a defect in the qualification result.

### S1. `restart.sh` fails if the app is not running
**File:** `spikes/ios-updates/restart.sh:23`
`xcrun simctl terminate` exits non-zero when the app is not running. Under `set -e` and `pipefail`, `restart.sh` then exits after it has already written a partial `restart-<label>.txt`. `rebuild.sh:39` already tolerates this case. The documented flow always has the app running, so the issue only shows up when an operator deviates from the flow.
```bash
  xcrun simctl terminate "$simulator" "$bundle_id" 2>/dev/null || true
```

### S2. Bundle identifier is hardcoded in one script and derived in the other
**File:** `spikes/ios-updates/restart.sh:7` and `spikes/ios-updates/rebuild.sh:37`
`rebuild.sh` reads `CFBundleIdentifier` from the built product's `Info.plist`. `restart.sh` hardcodes `org.reactjs.native.example.AgentUIUpdateProbe`. The two values match today because the template is pinned. Reading the plist from the same product path in both scripts would keep them consistent if the template ever drifts.

### S3. Document the build-log redaction step
**File:** `spikes/ios-updates/README.md:24-26`, `spikes/ios-updates/rebuild.sh:29-34`
`rebuild.sh` writes unredacted logs to the ignored `.work/evidence/`. The retained `.gz` logs were redacted by hand before they were committed, and the result is correct: 0 occurrences of `/Users/`. The README does not mention this step, so the next operator could commit raw paths. One line would cover it:
```sh
sed "s#$HOME#~#g" .work/evidence/build-A.log | gzip -9 > evidence/build-A.log.gz
```

### S4. Record whether the working tree is dirty
**File:** `spikes/ios-updates/rebuild.sh:29`, `spikes/ios-updates/restart.sh:10`
`git rev-parse HEAD` does not show whether the probe scripts had uncommitted edits. Appending `git status --porcelain -- .` (or `git describe --always --dirty`) would make the source attribution in the logs exact.

### S5. Print the log tail when the build fails (previously declined, still optional)
**File:** `spikes/ios-updates/rebuild.sh:30-34`
The earlier fix review declined this with a valid reason. I repeat it here only for completeness, not as a requirement.
