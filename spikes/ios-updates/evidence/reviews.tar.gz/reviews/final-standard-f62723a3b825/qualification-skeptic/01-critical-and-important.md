# Critical and Important Issues

## Critical

None found.

## Important

None found in the resulting source at `7d250ae`, or in the docs and evidence at `f62723a`.

### Validation of prior Important findings

- **I1 (8081 evidence): fixed.** `spikes/ios-updates/restart.sh:15-22` treats lsof exit 0
  (a listener exists) as a failure and propagates any status other than 1. Because
  `pipefail` is on, a failure inside the `{ … } | tee` group makes the script fail. Both
  retained restart logs record `lsof exit 1: no listener`.
- **I2 (unevidenced preconditions): fixed.** `restart-no-rebuild.txt` shows the source
  label B together with the A installed hash (`b95de99c…`, identical to `bundle-A.sha256`).
  This is the negative control the record needed: the source edit happened and the
  installed bundle did not change. `restart-B.txt` shows the B hash (`1fe9fe31…`). Distinct
  launch PIDs show that relaunches happened.
- **I3 (lock fidelity): fixed in source.** `spikes/ios-updates/prepare.sh:7` gates on
  CocoaPods 1.16.2. Lines 17-19 require the committed lock, run `pod install --deployment`,
  and `cmp` the lock afterward. `prepare-deployment.log` contains "Verifying no changes".
  `README.md:49` discloses the unlocked CLI bootstrap, and `native-template.sha256` pins
  the generated `Podfile`, `project.pbxproj` and `AppDelegate.swift`.
- **I4 (installed vs product hash): fixed.** `spikes/ios-updates/rebuild.sh:41-42` reads
  back from `simctl get_app_container … app` with a relative filename.
  `docs/qualification/ios-updates.md:74-76` now describes this correctly.
- **I5 (architecture cross-links): deferred to the owner, not a defect here.**
  `docs/qualification/ios-updates.md:84-87` scopes the record as a bounded v1
  recommendation and names the Linux coordinator as owner of the reconciliation. It
  states that no product update policy is implemented. No source in this branch
  contradicts `docs/architecture/boundaries.md`.

### Considered and not raised as Important

- `evidence/prepare-clean.log.gz` was produced by the pre-`230f062` `prepare.sh`: plain
  `pod install`, with no "Verifying no changes" line in the log. So doc row 64 (fresh
  template) and row 61 (deployment-mode lock check) come from two different runs. The
  combination still supports the claims. The lock check ran under the current script, and
  the template checksums cover template drift. The sequencing is also disclosed in lines
  79-82. I classify this as wording polish (S1), not a defect.
- In `restart.sh:11`, `grep -o` runs inside `echo "$(…)"`, so a missing label prints an
  empty value instead of aborting. The retained evidence shows the label, so this did not
  affect qualification. Listed as optional hardening (S2).
