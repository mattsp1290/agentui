# Action Items

Reviewer: Qualification skeptic (`qualification-skeptic`) · Branch `codex/ios-update-qualification` @ `f62723a3b825` (source `7d250ae`) · Verdict: **APPROVE**

## Action Items

### Critical
- (none)

### Important
- (none). Prior I1–I4 are verified fixed. I5 (architecture cross-links) is deferred to the Linux integration owner and scoped explicitly in `docs/qualification/ios-updates.md:84-87`.

### Suggestions
- [ ] [docs/qualification/ios-updates.md:64] Note that the clean-prepare log came from the pre-deployment-mode `prepare.sh`, and that the drift check is evidenced separately by `prepare-deployment.log`.
- [ ] [spikes/ios-updates/restart.sh:11] Assign `source_label="$(grep -o 'update probe [AB]' .work/app/index.js)"` before echoing it, so a missing label aborts under `set -e` instead of logging an empty value.
- [ ] [spikes/ios-updates/restart.sh:7] Optionally read the bundle ID from the installed app's `Info.plist` (as `rebuild.sh:37` does) instead of hard-coding it.
- [ ] [spikes/ios-updates/README.md:42-44] Cite `native-template.sha256` and the build log's `--dev false` line as the retained basis for the AppDelegate/Metro claim.
