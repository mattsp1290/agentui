# Suggestions (non-blocking, optional)

### S1. Say which prepare script produced the clean-prepare log

- **File:** `docs/qualification/ios-updates.md:64,79-82`
- **What and why:** The clean-prepare log comes from the earlier `prepare.sh`, which ran
  plain `pod install`. The deployment-mode drift check was exercised later on an existing
  tree (`prepare-deployment.log`). Lines 79-82 imply this order, but row 64 could be read as
  a fresh run of the current script.

  ```md
  | Fresh template generation with committed locks (pre-deployment-mode script), warm artifact cache, DerivedData retained | PASS | clean prepare log |
  ```

### S2. Fail when the source label cannot be read

- **File:** `spikes/ios-updates/restart.sh:11`
- **What and why:** If `grep` finds nothing inside `echo "$(…)"`, the script prints an empty
  label and keeps going, so the restart log loses the precondition it exists to prove.

  ```sh
  source_label="$(grep -o 'update probe [AB]' .work/app/index.js)"
  echo "Source label: $source_label"
  ```

### S3. Read the bundle identifier the same way in both scripts

- **File:** `spikes/ios-updates/restart.sh:7` vs `spikes/ios-updates/rebuild.sh:37`
- **What and why:** `rebuild.sh` reads `CFBundleIdentifier` from the built product.
  `restart.sh` hard-codes it. Both currently resolve to
  `org.reactjs.native.example.AgentUIUpdateProbe`, as the restart logs confirm. They
  would diverge only if the template's default changed, and the template checksums would
  show that.

### S4. Point the README's AppDelegate claim at retained evidence

- **File:** `spikes/ios-updates/README.md:42-44`
- **What and why:** The README says the Release bundle URL in `AppDelegate.swift` confirms
  that Metro is not needed. The file itself is not retained, but its checksum is
  (`native-template.sha256`), and the build logs show `--dev false`. Citing those makes the
  claim auditable.

### S5. Optional expansion, out of scope for this branch

Collecting evidence automatically, comparing A and B hashes automatically, and tailing
build logs on failure would all be expansions, not fixes. `fix-review.md` explains why
they were left out, and the embedded-revision assertion (`rebuild.sh:36`) plus the
installed readback already catch stale bundles.
