# Positive Notes

- **The restart log records its own preconditions.** `restart.sh:9-25` writes the source SHA,
  the source label, the installed hash, the result of the 8081 check and the launch PID into
  a single tee'd log. `restart-no-rebuild.txt` (label B, A hash) makes the most important
  negative control checkable from retained files.
- **The 8081 check fails closed.** In `restart.sh:16-21`, lsof exit 0 aborts, exit 1 is
  recorded as "no listener", and any other status propagates. Tool errors are not
  silently treated as a pass.
- **The lock is enforced in two layers.** `prepare.sh:17-19` runs
  `pod install --deployment` and then a byte `cmp`. The deployment log shows
  "Verifying no changes".
- **The embedded revision is asserted.** `rebuild.sh:36` greps the built `main.jsbundle` for
  the expected label before installing, so a stale bundle is caught at build time.
- **Hashes are read from the installed app.** `rebuild.sh:41-42` uses
  `get_app_container … app` and a relative filename. The installed-update claim now rests
  on more than screenshots, and the evidence no longer contains user paths.
- **Failures in the Node lookup stay visible.** `rebuild.sh:26-27` assigns `NODE_BINARY`
  separately from `export`, so `set -e` catches a failed `command -v`.
- **Evidence is tied to its provenance.** `rebuild.sh:29` writes the git SHA and
  `xcodebuild -version` at the top of each build log, and both logs show `7d250ae`. Logs are
  redacted to `~`.
- **The record's scope is honest.** The decision says "recommendation". Live updates,
  physical devices and integrated AgentUI are UNQUALIFIED. Row 64 discloses the warm cache
  and retained DerivedData. Row 67 says that verify excludes spikes.
- **The scripts are small.** The three scripts total 89 lines. They validate arguments
  before interpolating them into the heredoc (`rebuild.sh:6,14`) and guard against a
  simulator that is not booted (`rebuild.sh:10`).
