# Review Overview: Final Standard Pass

- **Branch:** `codex/ios-update-qualification`
- **Head:** `f62723a3b825ffb78d4552b5a9109b94fc73e0e5` (base `main`)
- **Implementation source:** `7d250ae` (`f62723a` adds only docs and evidence)
- **Date:** 2026-11-13
- **Reviewer:** Qualification skeptic
- **Reviewer slug:** `qualification-skeptic`
- **Role:** Independently challenge acceptance claims, missing cases and maintainability.
- **Prior pass:** `reviews/codex-ios-update-qualification-2026-11-13-195420-e4f3a963ccce/qualification-skeptic` (REQUEST_CHANGES, I1–I5) plus that run's `fix-review.md`

## Summary

The branch adds a standalone React Native 0.86.0 iOS probe under `spikes/ios-updates/`.
`prepare.sh` generates the community template, gates on Node, npm and CocoaPods versions,
runs `npm ci`, then runs `pod install --deployment` against the committed lock and
byte-compares the lock afterward. `rebuild.sh` writes an A/B `index.js` and builds Release
for the simulator. It asserts that the revision label is embedded in `main.jsbundle`, then
installs, relaunches, and hashes the **installed** bundle. The new `restart.sh` records the
source SHA, the source label, the installed-bundle hash and an `lsof` check on port 8081
(it fails if a listener exists), then terminates and relaunches the app. The qualification
record recommends rebuild-only iOS updates for v1. It marks live updates, physical devices
and integrated AgentUI as UNQUALIFIED.

I re-checked every prior Important finding against the current source and the retained
evidence:

| Prior | Status | Basis |
| --- | --- | --- |
| I1 no 8081 evidence | **Fixed** | `restart.sh:15-22` fails if a listener exists; `restart-B.txt` and `restart-no-rebuild.txt` both record `lsof exit 1: no listener` |
| I2 no-rebuild/restart preconditions unevidenced | **Fixed** | `restart-no-rebuild.txt` shows `Source label: update probe B` with installed hash `b95de99c…` (= `bundle-A.sha256`); `restart-B.txt` shows installed hash `1fe9fe31…` (= `bundle-B.sha256`); separate launch PIDs (27893, 28324); both logs carry source SHA `7d250ae` |
| I3 lock fidelity | **Fixed in source** | `prepare.sh:7,16-19`: pod version gate, mandatory lock, `--deployment`, `cmp`; `prepare-deployment.log` shows "Verifying no changes". Misleading bootstrap comment removed. Doc row 64 now says warm cache and retained DerivedData. Unlocked CLI bootstrap disclosed in `README.md:49`, mitigated by `native-template.sha256` |
| I4 installed vs build-product hash | **Fixed** | `rebuild.sh:41-42` hashes `get_app_container … app` with a relative name. Doc lines 74-76 are corrected |
| I5 architecture cross-links | **Accepted deferral** | Reserved for the Linux integration owner. Doc lines 84-87 call this a bounded recommendation with no implemented product policy, so it is not a defect in this branch's source |

I also confirmed that the build logs start with source SHA `7d250ae` and Xcode 26.2/17C52.
They show `bundle.js … --dev false` and `** BUILD SUCCEEDED **`, and their home paths are
redacted to `~` (0 `/Users/` occurrences). The Hermes version in the doc (250829098.0.14)
matches `Podfile.lock:3`. The verify log shows 11/11 tests passing.

## Verdict

**APPROVE.** The resulting source is sound. Every prior Important finding is fixed, or, for
I5, deferred to its owner with an explicit scope statement. The evidence now records its
own preconditions. I found no new Critical or Important defects. The remaining notes are
optional wording and robustness polish (see `02-suggestions.md`).

## Stats

- Files changed: 24 (`git diff main...HEAD --stat`); 10 binary evidence files
- Lines: +8590 / −0. About 8306 are the two generated dependency locks (`package-lock.json`,
  `Podfile.lock`). The handwritten scripts are 89 lines (`prepare.sh` 19, `rebuild.sh` 44,
  `restart.sh` 26).
- Commits: 5 (`b4258d6`, `e4f3a96`, `230f062`, `7d250ae`, `f62723a`)
