# Overview

- **Branch:** `codex/ios-update-qualification` (base `main`)
- **Reviewed HEAD:** `f62723a3b825ffb78d4552b5a9109b94fc73e0e5` (source last changed in `7d250ae`; `f62723a` only changes docs and evidence)
- **Date:** 2026-11-13
- **Reviewer:** Structural simplicity (`structural-simplicity`)
- **Role:** Strict review under the thermo-nuclear maintainability rubric (`.audit/thermo-rubric.md`, pinned revision `3dbd22ff12742fb28c9700b9760baa29ed41dc13`). It looks for structural regressions, chances to make the code much simpler, branching sprawl, boundary leaks and oversized files.

## Summary

The branch adds an isolated React Native iOS spike under `spikes/ios-updates/`. It checks a rebuild-only update path on the simulator. Three short Bash scripts do the work:

- `prepare.sh` (19 lines) generates the RN 0.86.0 template into ignored `.work/` and installs the committed npm and CocoaPods locks. It runs `pod install --deployment` and then `cmp` to catch lock drift.
- `rebuild.sh` (44 lines) writes an A/B `index.js`, builds Release with an embedded bundle, checks that the revision string is inside `main.jsbundle`, installs and launches the app, and hashes the bundle read back from the installed app.
- `restart.sh` (26 lines) records the source label, the installed-bundle hash and whether anything listens on Metro port 8081. It then terminates and relaunches the app and tees everything to an evidence file.

`docs/qualification/ios-updates.md` records the rebuild-only v1 recommendation with a results table, plus the retained evidence (screenshots, gzipped logs with `$HOME` replaced by `~`, hashes and restart logs).

Nothing touches shared product code or other workspaces. The main workspace lockfile is unchanged. The record says plainly that this is a recommendation and that no product update policy is implemented.

## Verdict: **APPROVE**

Against the rubric's approval bar:

- **Structural regressions:** none. The spike is a separate leaf with its own dependency tree and no imports into or out of `apps/`/`packages/`.
- **Missed big simplification:** none visible. Each script is a straight, linear sequence of commands, and the three steps (prepare, rebuild, restart) are naturally separate operator actions. Merging them into one script with modes would add branching, not remove it.
- **File-size growth:** only the two generated lockfiles (`Podfile.lock` 2138 lines, `package-lock.json` 6168 lines) are over 1k lines. Their package managers read them whole, and splitting them would break those tools. This is a justified waiver. The handwritten scripts total 89 lines.
- **Branching sprawl or hacky magic:** none. The only multi-way branch is the `lsof` exit-status check in `restart.sh:16-22`, which is explicit and correct.
- **Boundary leaks:** none. Cross-links to the architecture docs are reserved to the Linux integration owner, and the record states this (`docs/qualification/ios-updates.md:84-87`).

Earlier blocking findings from the `e4f3a963ccce` dual review are fixed (details in `03-positive-notes.md`). What remains is two small duplication suggestions. Neither blocks merging.

## Stats

- Files changed: 24 (3 scripts, 2 docs, `package.json`, `.gitignore`, 2 generated lockfiles, 15 evidence artifacts)
- Lines: +8590 / −0 (of which 8306 are generated lockfiles)
- Commits: 5 (`b4258d6`, `e4f3a96`, `230f062`, `7d250ae`, `f62723a`)
