# Action Items

Reviewer: Structural simplicity (`structural-simplicity`) · Branch `codex/ios-update-qualification` @ `f62723a3b825` · Verdict: **APPROVE**

## Action Items

### Critical
- (none)

### Important
- (none)

### Suggestions
- [ ] [spikes/ios-updates/restart.sh:7] Stop hard-coding `org.reactjs.native.example.AgentUIUpdateProbe`. Read it the way `rebuild.sh:37` does: `bundle_id=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$PWD/.work/build/Build/Products/Release-iphonesimulator/AgentUIUpdateProbe.app/Info.plist")`. This leaves one source of truth for the bundle ID across both scripts. Optional.
- [ ] [spikes/ios-updates/prepare.sh:4-6, spikes/ios-updates/rebuild.sh:7-9] Optionally move the duplicated Node 24.22.3 / npm 11.19.1 gate into a sourced `spikes/ios-updates/toolchain.sh`, so a version bump is one edit (`package.json:16` `engines` also repeats the versions). Acceptable as-is for a frozen spike.
- [ ] [spikes/ios-updates/restart.sh:11] Optional scope expansion: for `label == no-rebuild`, enforce the README precondition with `grep -q 'update probe B' .work/app/index.js || { echo 'Edit index.js to B first.' >&2; exit 1; }`. Today the label is only recorded, and it prints empty instead of failing if `grep` finds nothing.
