# Suggestions (non-blocking)

These are optional improvements, not defects. The spike is correct and readable without them.

## 1. Bundle identifier is defined in two places

- `spikes/ios-updates/rebuild.sh:37` reads `CFBundleIdentifier` from the built product's `Info.plist`.
- `spikes/ios-updates/restart.sh:7` hard-codes `org.reactjs.native.example.AgentUIUpdateProbe`.

If the template's default identifier changes, `restart.sh` silently targets a different app ID while `rebuild.sh` keeps working. Two sources of truth for one value is a small boundary smell. The simplest fix is for `restart.sh` to read the identifier the same way `rebuild.sh` does:

```bash
product="$PWD/.work/build/Build/Products/Release-iphonesimulator/AgentUIUpdateProbe.app"
bundle_id=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$product/Info.plist")
```

Hard-coding it in both scripts would also be fine, as long as there is one name and one source. The current mix of read-in-one, hard-coded-in-the-other is the part to avoid.

## 2. Toolchain version gate is duplicated three times

`prepare.sh:4-6` and `rebuild.sh:7-9` repeat the same Node/npm check, and `package.json:16` declares the same versions in `engines`. This is small (three lines each), but bumping a version means three edits.

Optional fix: put the gate in one sourced file.

```bash
# spikes/ios-updates/toolchain.sh
[[ "$(node --version)" == v24.22.3 && "$(npm --version)" == 11.19.1 ]] || {
  echo 'Use Node 24.22.3 and npm 11.19.1.' >&2; exit 1;
}
```

Then call `source ./toolchain.sh` from both scripts. Do this only if the probe stays around long enough to need a version bump. For a frozen qualification spike, the inline duplication is acceptable.

## 3. (Optional) `restart.sh` could check that the source label matches the scenario

`restart.sh:11` records `Source label` but does not enforce it. For the `no-rebuild` run, the README asks the operator to edit `index.js` to B first. A one-line guard such as `[[ "$label" != no-rebuild ]] || grep -q 'update probe B' .work/app/index.js` would turn that operator step into a checked precondition.

Also, `echo "Source label: $(grep ...)"` does not stop the script when `grep` finds nothing, because `errexit` ignores failures inside command substitutions used as `echo` arguments. The label would just print empty. The retained evidence shows `update probe B` in both runs, so this did not affect the recorded result. This adds scope and is not required.
