# Critical and Important Issues

## Critical

None.

## Important

None.

### Considered and rejected

These were examined under the rubric and do not count as defects:

- **Lockfiles over 1k lines** (`spikes/ios-updates/Podfile.lock`, `spikes/ios-updates/package-lock.json`). npm and CocoaPods generate these files and read them as single files. Splitting them is impossible without breaking `npm ci` and `pod install --deployment`. The file-size presumption is waived for a compelling structural reason.
- **Architecture docs not reconciled** (`docs/architecture/boundaries.md`, `docs/architecture/apple-qualification.md`). The Linux integration owner holds this reservation. The record says so (`docs/qualification/ios-updates.md:84-87`) and implements no product policy. This is ownership-scoped follow-up, not a boundary leak on this branch.
- **`restart.sh:16-22` if/else on the `lsof` exit status.** This looks like an unusual branch, but it is the minimal correct three-way split: 0 means a listener exists (fail), 1 means no listener (pass), anything else is a real `lsof` error (propagate). Inside the `else` arm, `$?` is the condition's status, so the logic is sound. Collapsing it to `! lsof ...` would hide `lsof` failures as "no listener".
- **Exit behavior of the `{ ... } | tee` group in `restart.sh:9-25`.** With `set -o pipefail`, an `exit 1` inside the group fails the pipeline, and `errexit` stops the script. Failures are not swallowed by `tee`.
- **`prepare.sh:19` `cmp` after `pod install --deployment`.** This is partly redundant, because deployment mode already refuses to change the lock. It costs one line and makes the drift check explicit and readable in the logs. Not worth removing.
- **`rebuild.sh` unquoted heredoc** (lines 14-24). `$revision` is the only expansion, and line 6 has already limited it to `A`/`B`. The intent is commented. No injection or quoting hazard.
