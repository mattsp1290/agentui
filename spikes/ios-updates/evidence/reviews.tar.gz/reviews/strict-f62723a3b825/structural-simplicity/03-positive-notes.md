# Positive Notes

## Structure

- **Strict isolation.** Everything lives in `spikes/ios-updates/`. Generated app code and native template output stay in the ignored `.work/` directory (`.gitignore:1`). The spike has its own lockfiles and leaves the main workspace lock unchanged. There are no feature checks or special cases in shared code, which is the cleanest possible boundary for a qualification spike.
- **Three linear scripts, each matching one operator step.** There are no modes, flags or shared state beyond `.work/`. Arguments are validated up front against closed sets (`rebuild.sh:6` A|B, `restart.sh:6` no-rebuild|B). After that, each script runs straight through under `set -euo pipefail`.
- **The generated app is not committed.** Committing the generated app would have added thousands of lines of template output. Instead, the branch keeps a three-line checksum of the parts that matter (`evidence/native-template.sha256`: Podfile, `project.pbxproj`, `AppDelegate.swift`). This is how to keep the diff small without losing drift detection.

## Fixes from the `e4f3a963ccce` review, checked against current source

| Prior finding | Status | Where |
| --- | --- | --- |
| Lock fidelity not enforced; missing-lock guard | Fixed: unconditional `cp` fails under `set -e` if the lock is missing; `pod install --deployment`; `cmp` | `prepare.sh:17-19` |
| No CocoaPods version gate | Fixed | `prepare.sh:7` |
| Hash read from the build product, not the installed app; absolute paths in the hash files | Fixed: hashes `get_app_container ... app` with a relative filename | `rebuild.sh:41-42`; `evidence/bundle-*.sha256` |
| No restart evidence (label, hash, 8081, PID) | Fixed: `restart.sh` tees all four | `restart.sh:9-25`; `evidence/restart-*.txt` |
| Embedded revision not machine-checked | Fixed | `rebuild.sh:36` |
| Simulator not checked as booted | Fixed | `rebuild.sh:10` |
| Build log not tied to a revision | Fixed: `git rev-parse HEAD` and `xcodebuild -version` header | `rebuild.sh:29` |
| Unquoted heredoc intent | Fixed: comment | `rebuild.sh:14` |
| `$HOME` in committed logs | Fixed: sampled `build-B.log.gz` shows `~/git/agentui/...` | evidence logs |
| Global `pod` vs template Gemfile | Documented | `README.md:48` |
| Template drift from unlocked `npx` init | Documented and checksummed | `README.md:49-50`; `native-template.sha256` |
| Node provisioning | Documented | `README.md:63-66` |
| Fresh-prepare wording (warm caches) | Fixed | `docs/qualification/ios-updates.md:64` |
| Architecture-doc reconciliation | Deferred to the Linux integration owner, stated in the record | `docs/qualification/ios-updates.md:84-87` |

`7d250ae` split `export NODE_BINARY="$(command -v node)"` into an assignment followed by `export` (`rebuild.sh:26-27`). This fixes ShellCheck SC2155: when export and command substitution are combined, `export`'s success hides a failing `command -v`. With the split, `set -e` now catches a missing `node`. Correct and minimal.

## Evidence

- `restart-no-rebuild.txt` and `restart-B.txt` together show the claim directly: the same source label B, two different installed hashes (`b95de99c…` vs `1fe9fe31…`, matching `bundle-A/B.sha256`), no listener on 8081, and a new launch PID each time.
- The three-way `lsof` exit handling (`restart.sh:16-22`) refuses to treat an `lsof` error as "no Metro". This is the kind of explicit invariant the rubric asks for in place of a silent fallback.
- The qualification doc separates PASS rows from UNQUALIFIED ones (live update, physical device, integrated AgentUI) and does not overclaim.
